<?php

return [
    'categories' => [
        'index',
        'add',
        'edit',
        'view',
        'process',
        'remove'
    ]
];