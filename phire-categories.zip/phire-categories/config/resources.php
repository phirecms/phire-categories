<?php

return [
    'categories' => [
        'index',
        'add',
        'edit',
        'remove'
    ]
];